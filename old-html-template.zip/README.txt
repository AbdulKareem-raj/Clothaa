NORTHLINE JACKET STORE TEMPLATE (PLACEHOLDER BRAND)
1. Extract this ZIP.
2. Open index.html in a browser to preview. Internet is needed for the sample remote photos.
3. Change "Northline" throughout the HTML files and replace assets/logo.svg with your brand logo or edit the SVG text.
4. Edit js/products.js to replace sample names, USD prices, descriptions and images with your real stock.
5. Upload the entire folder structure to your web host or static hosting such as Netlify/GitHub Pages.

INCLUDED: home, shop/catalogue, individual product details, cart, about, contact and policy pages; responsive CSS; search, category filters, sorting, size selector, cart quantity/remove controls; SVG logo.

IMPORTANT: This is a front-end demo. The cart uses browser storage only. Cash on Delivery is a preference demo and does not submit orders. Online payments do not work until you integrate a secure payment provider and server-side order backend. Do not collect card details directly in these files. The newsletter form is a demo. Contact form prepares an email via the visitor's email app. Replace placeholder contact details and add accurate shipping, returns, privacy and terms policies before launch. Sample product imagery may not depict the actual product; replace with your own licensed photos. Prices are in USD.
